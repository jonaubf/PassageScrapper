<?php
$ini = file('bibleqt.ini');
$shortnames = '';
foreach($ini as $line)
{
  list($name, $val) = split('=', $line, 2);
  switch(trim($name))
  {
  case 'PathName':
    break;
  case 'FullName':
    break;
  case 'ShortName':
    $shortnames.= str_replace(' ', '|', trim($val))."\n";
    break;
  default:
    break;
  }
}
echo $shortnames;